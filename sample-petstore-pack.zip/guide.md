# How to call — Petstore Lite API

Base URL: `https://api.petstore-lite.example.com/v1`

- **apiKey** (apiKey): send `X-API-Key` in header
Global security requirement present (1 option(s)).

## GET /pets

List pets

### curl

```bash
curl -sS -X GET 'https://api.petstore-lite.example.com/v1/pets?' \
  -H 'X-API-Key: YOUR_API_KEY' \
  -H 'Accept: application/json'
```

### JavaScript (fetch)

```javascript
const res = await fetch('https://api.petstore-lite.example.com/v1/pets?', {
  method: 'GET',
  headers: {
    'Accept': 'application/json',
    'X-API-Key': process.env.API_KEY,
  },
});
const data = await res.json();
```

### Python (requests)

```python
import os, requests

url = "https://api.petstore-lite.example.com/v1/pets?"
headers = {"Accept": "application/json"}
headers["X-API-Key"] = os.environ["API_KEY"]
r = requests.request("GET", url, headers=headers)
r.raise_for_status()
print(r.json() if r.content else r.status_code)
```

## POST /pets

Create a pet

### curl

```bash
curl -sS -X POST 'https://api.petstore-lite.example.com/v1/pets' \
  -H 'X-API-Key: YOUR_API_KEY' \
  -H 'Accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "name": "string",
  "status": "available",
  "tags": [
    "string"
  ]
}'
```

### JavaScript (fetch)

```javascript
const res = await fetch('https://api.petstore-lite.example.com/v1/pets', {
  method: 'POST',
  headers: {
    'Accept': 'application/json',
    'X-API-Key': process.env.API_KEY,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
  "name": "string",
  "status": "available",
  "tags": [
    "string"
  ]
}),
});
const data = await res.json();
```

### Python (requests)

```python
import os, requests

url = "https://api.petstore-lite.example.com/v1/pets"
headers = {"Accept": "application/json"}
headers["X-API-Key"] = os.environ["API_KEY"]
payload = {
  "name": "string",
  "status": "available",
  "tags": [
    "string"
  ]
}
r = requests.request("POST", url, headers=headers, json=payload)
r.raise_for_status()
print(r.json() if r.content else r.status_code)
```

## GET /pets/{petId}

Get pet by ID

### curl

```bash
curl -sS -X GET 'https://api.petstore-lite.example.com/v1/pets/id_here' \
  -H 'X-API-Key: YOUR_API_KEY' \
  -H 'Accept: application/json'
```

### JavaScript (fetch)

```javascript
const res = await fetch('https://api.petstore-lite.example.com/v1/pets/id_here', {
  method: 'GET',
  headers: {
    'Accept': 'application/json',
    'X-API-Key': process.env.API_KEY,
  },
});
const data = await res.json();
```

### Python (requests)

```python
import os, requests

url = "https://api.petstore-lite.example.com/v1/pets/id_here"
headers = {"Accept": "application/json"}
headers["X-API-Key"] = os.environ["API_KEY"]
r = requests.request("GET", url, headers=headers)
r.raise_for_status()
print(r.json() if r.content else r.status_code)
```

---

Not legal advice. Confirm auth, rate limits, and ToS with the API owner.
